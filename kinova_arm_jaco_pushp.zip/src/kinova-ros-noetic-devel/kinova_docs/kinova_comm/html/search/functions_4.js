var searchData=
[
  ['initfingers',['initFingers',['../classkinova_1_1_kinova_comm.html#a7c42a679d60a49e59b566f167ddfcf85',1,'kinova::KinovaComm']]],
  ['isclosetoother',['isCloseToOther',['../classkinova_1_1_kinova_pose.html#a6d1209a7e6d85b4f6aa5cfc913fa016b',1,'kinova::KinovaPose::isCloseToOther()'],['../classkinova_1_1_kinova_angles.html#a628b0b9aa2de4b965c651a6824766c60',1,'kinova::KinovaAngles::isCloseToOther()']]],
  ['ishomed',['isHomed',['../classkinova_1_1_kinova_comm.html#ac82fe58ca6589b0a8670a0c4b61f1bca',1,'kinova::KinovaComm']]],
  ['isstopped',['isStopped',['../classkinova_1_1_kinova_comm.html#ac6646ee050da0fdb997682549a147425',1,'kinova::KinovaComm']]]
];
